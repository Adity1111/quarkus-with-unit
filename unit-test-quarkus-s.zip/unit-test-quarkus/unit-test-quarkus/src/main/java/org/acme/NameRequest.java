package org.acme;

public class NameRequest {
    public String name;
}