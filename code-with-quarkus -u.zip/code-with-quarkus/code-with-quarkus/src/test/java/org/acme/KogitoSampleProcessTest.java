// package org.acme;

// import io.quarkus.test.junit.QuarkusTest;
// import org.junit.jupiter.api.Test;
// import org.kie.kogito.test.api.KogitoProcessTest;
// import org.kie.kogito.test.api.KogitoService;
// import org.kie.kogito.process.Process;
// import org.kie.kogito.process.ProcessInstance;

// import java.util.HashMap;
// import java.util.Map;

// import static org.junit.jupiter.api.Assertions.assertEquals;
// import static org.junit.jupiter.api.Assertions.assertNotNull;

// @QuarkusTest
// @KogitoProcessTest(process = "sample") // Matches the BPMN process id
// public class KogitoSampleProcessTest {

//     @KogitoService("sample") // Inject the service for the "sample" process
//     Process<? extends Object> sampleProcess;

//     @Test
//     public void testSampleProcessHappyPath() {
//         assertNotNull(sampleProcess, "Process should not be null");

//         // Define input variables
//         Map<String, Object> params = new HashMap<>();
//         params.put("sampleInput", "Input Text");

//         // Create and start the process
//         ProcessInstance<?> instance = sampleProcess.createInstance(params);
//         instance.start();

//         // Assert process completed successfully
//         assertEquals(ProcessInstance.STATE_COMPLETED, instance.status());

//         // Validate expected output
//         Object output = instance.variables().get("sampleOutput");
//         assertEquals("This is outputText", output);
//     }
// }
