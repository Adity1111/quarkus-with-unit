package org.acme;

import io.quarkus.test.junit.QuarkusTest;

import io.restassured.http.ContentType;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.notNullValue;

@QuarkusTest
public class MyRestApiTest { 

    @Test
    public void testCreateSample() {
        String orderPayload = "{\n    \"sampleInput\": \"Input Text\"\n    \n\n    \n}";

        given()
          .contentType(ContentType.JSON)
          .body(orderPayload)
          .when().post("/sample")
          .then()
             .statusCode(201)
             .contentType(ContentType.JSON)
             .body("id", notNullValue()) ;// Verify that an ID is generated
            
    }
}